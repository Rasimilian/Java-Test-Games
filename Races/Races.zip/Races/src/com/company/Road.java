package com.company;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.Random;
import java.util.List;


public class Road extends JPanel implements ActionListener, Runnable {
    Timer timer = new Timer(20,this);

    Image img = new ImageIcon("images/road.png").getImage();

    Player player = new Player();

    Thread enemiesFactory = new Thread(this);

    List<Enemy> enemies = new ArrayList<Enemy>();

    int num;

    public void paint (Graphics g) {
        g = (Graphics2D) g;
        g.drawImage(img,player.layer1,100,null);
        g.drawImage(img,player.layer2,100,null);
        g.drawImage(player.img,player.x,player.y,null);

        double v = player.v;

        g.drawRect(100,50,170,50);
        g.fillRect(100,50,170,50);
        g.setColor(Color.white);
        Font font = new Font("Arial", Font.ITALIC,20);
        g.setFont(font);
        g.drawString("Speed: " + v + " km/h", 110,80);
        //g.drawString("Streak: " + player.streak + " Alenas", 110,80);

        Iterator<Enemy> i = enemies.iterator();
        while (i.hasNext()) {
            Enemy e = i.next();
            if (e.x >=2200 || e.x <= -2200) {
                i.remove();
            } else {
                e.move();
                g.drawImage(e.img,e.x,e.y,null);
            }

        }

    }

    public Road() {
        timer.start();
        enemiesFactory.start();
        addKeyListener(new MyKeyAdapter());
        setFocusable(true);


    }

    public void actionPerformed (ActionEvent e) {
        player.move();
        repaint();
        testCollisionWithEnemies();
    }

    public void testCollisionWithEnemies() {
        Iterator<Enemy> i = enemies.iterator();
        while (i.hasNext()) {
            Enemy e = i.next();
            if (player.getRect().intersects(e.getRect())) {
                //num = 1;
                //if (num == 1) player.streak += num;
                //JOptionPane.showMessageDialog(null, "Defeated!");
                //System.exit(1);
            }

        }

    }

    @Override
    public void run() {
        while (true) {
            Random rand = new Random();
            try {
                Thread.sleep(rand.nextInt(2000));
                enemies.add(new Enemy(800,100+rand.nextInt(200),5+rand.nextInt(20),this));
            } catch (InterruptedException e) {
                e.printStackTrace();
            }

        }
    }

    private class MyKeyAdapter extends KeyAdapter {
        public void keyPressed (KeyEvent e) {
            player.keyPressed(e);
        }

        public void keyReleased (KeyEvent e) {
            player.keyReleased(e);
        }
    }


}
